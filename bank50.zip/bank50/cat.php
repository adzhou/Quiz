<?php
include 'inc.page.php';
@main($pin['bsb'],$cat,$name,$cmd,$inc,$inv,$cat2);
@down();

function main($bsb,$cat,$name,$cmd,$inc,$inv,$cat2){
	$pid=$bsb['pid'];
	echo '<p>',lang(2101),': ',lang(618)," <b class='green'>$pid</b></p>";
	$Inc=explode(',',$bsb['cat_income']);
	$Inv=explode(',',$bsb['cat_invest']);
	$ccy_list=$bsb['ccy'];
	$cat=ceil($cat); $cat2=ceil($cat2);
	if ($cat<1) $cat='';
	if ($cat2<1) $cat2='';
	main_form($pid,$cat,$name,$cmd,$inc,$inv,$Inc,$Inv,$cat2);
	$bsb=cms_row("select * from bsb_account where pid=$pid");
	$Inc=explode(',',$bsb['cat_income']);
	$Inv=explode(',',$bsb['cat_invest']);
	main_cat_list($ccy_list,$pid,$Inc,$Inv);
	echo '<p>',lang(2102),':</p><p>',lang(2103),'</p>';
}
function main_cat_bala_init(&$bala,$ccy,$cat,$amt,$num,$qty){
	$c=&$bala[$ccy][$cat];
	$c[0]+=$amt; $c[1]+=$num; $c[2]+=$qty;
	$c1=substr($cat,0,1);
	if ($c1<>$cat){
		$c=&$bala[$ccy][$c1];
		$c[0]+=$amt; $c[1]+=$num; $c[2]+=$qty;
	}
	$c3=substr($cat,0,3);
	if ($c3<>$cat){
		$c=&$bala[$ccy][$c3];
		$c[0]+=$amt; $c[1]+=$num; $c[2]+=$qty;
	}
}
function main_cat_list($ccy_list,$pid,$Inc,$Inv){
	$rows=cms_rows("select ccy,credit,debit,sum(amt),count(*),sum(qty) from bsb_book where pid=$pid group by 1,2,3 order by 1");
	foreach ($rows as $row){//seems there is memory leak, pls test again in the future
		main_cat_bala_init($bala,$row[0],$row[1],$row[3],$row[4],0-$row[5]);
		main_cat_bala_init($bala,$row[0],$row[2],0-$row[3],$row[4],$row[5]);
	}
	$CCY=cms_row("select distinct ccy from bsb_book where pid=$pid",1);
	echo "<table class='grid'><tr class='bg1'><td colspan='5'>",lang(2104),"</td>";
	if (is_array($CCY)){
		foreach ($CCY as $k) echo "<td class='ar'>{$ccy_list[$k]}</td>";
	}else echo '<td></td>';
	echo "<td class='ar'>",lang(2107),"</td><td class='ar'>QTY</td><td></td></tr>";
	$arr=cms_row("select cat,category from bsb_category where pid=$pid order by 1",2);
	$seek_link=" title='".lang(603)."' href='search.php?cat[0]=";
	foreach ($arr as $k=>$v){if ($k<10){
		$is_inc=in_array($k,$Inc);
		$is_inv=in_array($k,$Inv);
		if ($is_inc || $is_inv){
			$incinv='( ';
			if ($is_inc) $incinv .=lang(2108);
			if ($is_inv) $incinv .=lang(2109);
			$incinv.=')';
		}elseif ($k==9) $incinv='( '.lang(2105).' )';
		else $incinv='';
		$add_link=" title='".lang(602)."' href='add.php?rec[".($is_inc ? 'credit' : 'debit').']=';
		echo "<tr><td class='bg1 b' colspan='5'><a$add_link$k'>$k:</a> <a$seek_link$k'>$v</a> $incinv</td>",main_cat_bala($bala,$k,$is_inc,$CCY),"</tr>";
		foreach ($arr as $k2=>$v2){if (strlen($k2)==3 && substr($k2,0,1)==$k){
			echo "<tr><td>&nbsp;</td><td colspan='4'><a$add_link$k2'>$k2:</a> <a$seek_link$k2'>$v2</a></td>",main_cat_bala($bala,$k2,$is_inc,$CCY),"</tr>";
			foreach ($arr as $k3=>$v3){if (strlen($k3)==5 && substr($k3,0,3)==$k2){
				echo "<tr><td></td><td>&nbsp;</td><td colspan='3'><a$add_link$k3' class='orange'>$k3:</a> <a$seek_link$k3' class='orange'>$v3</a></td>",main_cat_bala($bala,$k3,$is_inc,$CCY),"</tr>";
				foreach ($arr as $k4=>$v4){if (strlen($k4)==7 && substr($k4,0,5)==$k3){
					echo "<tr><td></td><td></td><td>&nbsp;</td><td colspan='2'><a$add_link$k4' class='grey'>$k4:</a> <a$seek_link$k4' class='grey'>$v4</a></td>",main_cat_bala($bala,$k4,$is_inc,$CCY),"</tr>";
					foreach ($arr as $k5=>$v5){if (strlen($k5)==9 && substr($k5,0,7)==$k4)
						echo "<tr><td></td><td></td><td></td><td>&nbsp;</td><td><a$add_link$k5'>$k5:</a> <a$seek_link$k5'>$v5</a></td>",main_cat_bala($bala,$k5,$is_inc,$CCY),"</tr>";
					}
				}}
			}}
		}}
	}}
	echo '</table>';
}
function main_cat_bala($bala,$cat,$is_inc,$CCY){
	if ($cat<10) $bg=' bg1 b';
	elseif ($cat>9999) $bg=' opa5';
	foreach ($CCY as $v){
		$qty+=$bala[$v][$cat][2];
		$num+=$bala[$v][$cat][1];
		$amt=$bala[$v][$cat][0];
		if (!$is_inc) $amt=0-$amt;
		$str.="<td class='ar$bg'><span class='".($amt<0 ? 'red' : 'green')."'>".number_format($amt/100,2)."</span></td>";
	}
	if (!$str) $str='<td></td>';
	return $str."<td class='ar".($num>0 ? ' red' : '')."'>$num ".lang(2110)."</td><td class='ar'>".(substr($cat,0,1)==9 ? $qty : '')."</td><td><a href='cat.php?cat=$cat' class='green none'>".lang(616)."</a> &nbsp;<a href='cat.php?cat=$cat&#38;cmd=del' class='green'>".lang(2111)."</a></td>";
}
function main_form($pid,$cat,$name,$cmd,$inc,$inv,$Inc,$Inv,$cat2){
	if ($cat && !$cmd){
		$name=cms_var("select category from bsb_category where pid=$pid and cat='$cat'");
		if (in_array(substr($cat,0,1),$Inc)) $inc=1;
		if (in_array(substr($cat,0,1),$Inv)) $inv=1;
	}elseif ($cat && $cmd) $err=save_data($pid,$cat,$name,$cmd,$inc,$inv,$Inc,$Inv,$cat2);
	echo cms_form(),lang(609),': ',cms_form('text','cat',$cat,100),' ',lang(2112),': ',cms_form('text','name',$name,100),' ';
	if ($cat<10) echo cms_form('checkbox','inc',$inc,'','','',array(1=>lang(2108).' &nbsp;')),
		cms_form('checkbox','inv',$inv,'','','',array(1=>lang(2109).' &nbsp;'));
	echo cms_form('hidden','cmd','save'),cms_form('submit','dummy',lang(2113)),'</form>',
		cms_form(),lang(609),': ',cms_form('text','cat',$cat,100),' ',lang(2106),': ',cms_form('text','cat2',$cat2,100),' ',
		cms_form('hidden','cmd','move'),cms_form('submit','dummy',lang(2124),'','',"onclick=\"return confirm('".lang(2125)."')\""),'</form><br>';
	if ($err) echo "<p class='err'>$err</p>";
}
function move_data($pid,$c1,$c2){
	cms_run("update bsb_book set credit='$c2' where credit='$c1' and pid=$pid and debit<>'$c2'");
	cms_run("update bsb_book set debit='$c2' where debit='$c1' and pid=$pid and credit<>'$c2'");
	echo "<p class='ok'>BSB # $pid : FM $c1 TO $c2 : OK</p>";
}
function save_data($pid,$cat,$name,$cmd,$inc,$inv,$Inc,$Inv,$cat2){
	if ($cmd=='move') return move_data($pid,$cat,$cat2);
	if ($cat<10){
		if ($inc && $inv) unset($inv);//income can not be invest at the same time ?
		if (!$inc || !$inv || $cmd=='del'){
			foreach ($Inc as $k=>$v){
				if ($v==$cat && !$inc) unset($Inc[$k]);
			}
			foreach ($Inv as $k=>$v){
				if ($v==$cat && !$inv) unset($Inv[$k]);
			}
		}
		if ($cmd=='save'){
			if ($inc && !in_array($cat,$Inc)) $Inc[]=$cat;
			if ($inv && !in_array($cat,$Inv)) $Inv[]=$cat;
		}
		$str_inc=implode(',',$Inc);
		if (substr($str_inc,0,1)==',') $str_inc=substr($str_inc,1);
		$str_inv=implode(',',$Inv);
		if (substr($str_inv,0,1)==',') $str_inv=substr($str_inv,1);
		cms_sql('update','bsb_account',null,null,"cat_income='$str_inc',cat_invest='$str_inv' where pid=$pid");
	}
	if ($cmd=='del'){
		$num=cms_var("select count(*) from bsb_book where pid=$pid and (credit like '$cat%' or debit like '$cat%')");
		if ($num) return lang(2114,array($cat,$num));
		$num=cms_var("select count(*) from bsb_category where pid=$pid and cat like '$cat"."__'");
		if ($num) return lang(2115,array($cat,$num));
		cms_sql('delete','bsb_category',null,null,"where pid=$pid and cat='$cat'");
	}elseif ($cmd=='save'){
		if ($cat<1 || $cat>999999999) return lang(2116).": 1-999999999";
		$name=str_replace("'",'',cms_strip($name,1,1,'sql'));
		if (!$name) return lang(2117);
		if (cms_var("select 1 from bsb_category where category='$name' and pid=$pid and cat<>'$cat' limit 1")) return lang(2118);
		$col=array('pid','cat','category');
		$val=array($pid,$cat,$name);
		if ($cat<10){//level 1
			cms_sql('delete','bsb_category',null,null,"where pid=$pid and cat='$cat'");
			cms_sql('insert','bsb_category',$col,$val);
			return;
		}
		if ($cat<101) return lang(2119);
		$level1=substr($cat,0,1);
		if (!cms_var("select 1 from bsb_category where pid=$pid and cat='$level1' limit 1")) return lang(2120,$level1);
		if ($cat<999){//level 3 xxx
			cms_sql('delete','bsb_category',null,null,"where pid=$pid and cat='$cat'");
			cms_sql('insert','bsb_category',$col,$val);
			return;
		}
		if ($cat<10001) return lang(2119);
		$level2=substr($cat,0,3);
		if (!cms_var("select 1 from bsb_category where pid=$pid and cat='$level2' limit 1")) return lang(2121,$level2);
		if ($cat<99999){//level 3 xxx
			cms_sql('delete','bsb_category',null,null,"where pid=$pid and cat='$cat'");
			cms_sql('insert','bsb_category',$col,$val);
			return;
		}
		if ($cat<1000001) return lang(2119);
		$level3=substr($cat,0,5);
		if (!cms_var("select 1 from bsb_category where pid=$pid and cat='$level3' limit 1")) return lang(2122,$level3);
		if ($cat<9999999){//level 3 xxx
			cms_sql('delete','bsb_category',null,null,"where pid=$pid and cat='$cat'");
			cms_sql('insert','bsb_category',$col,$val);
			return;
		}
		if ($cat<100000001 || $cat>999999999) return lang(2119);
		$level4=substr($cat,0,7);
		if (!cms_var("select 1 from bsb_category where pid=$pid and cat='$level4' limit 1")) return lang(2123,$level3);
		cms_sql('delete','bsb_category',null,null,"where pid=$pid and cat='$cat'");
		cms_sql('insert','bsb_category',$col,$val);
	}
}
?>
