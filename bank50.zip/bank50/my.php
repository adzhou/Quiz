<?php
include 'inc.page.php';
@main($pin['bsb'],$per,$cmd,$pin['lang']);
@down();

function main($bsb,$per,$cmd,$lang){
	$arr_lang=array('cn'=>'中文','en'=>'English');
	if ($cmd) $err=save_data($bsb,$per);
	$per['ccy']=explode(',',$bsb['ccy_list']);
	echo cms_form(),'<p>',lang(2601),'</p>';
	if ($err) echo "<p class='ok'>$err</p>";
	foreach ($per['ccy'] as $c) $arr_ccy_defa[$c]=$bsb['ccy'][$c];
	echo "<table><tr><td width='90'>",lang(2602),": &nbsp;</td><td>$bsb[pid]</td></tr>
<tr><td>",lang(2618),':</td><td>',cms_form('select','lang',$lang,180,$arr_lang,"onchange=\"document.location='my.php?lang='+this.options[this.selectedIndex].value\""),"</td></tr>
<tr><td>",lang(2603),':</td><td>',cms_form('radio','per[rep_round]',(isset($per['rep_round']) ? $per['rep_round'] : $bsb['rep_round']),' &nbsp; ',array(2=>lang(2610),0=>lang(2608),'-2'=>lang(2612),'-3'=>lang(2613))),"</td></tr>
<tr><td>",lang(2604),':</td><td>',cms_form('checkbox','per[ccy][]',$per['ccy'],'',$bsb['ccy']),"</td></tr>
<tr><td>",lang(2605),':</td><td>',cms_form('select','per[ccy_default]',$per['ccy'][0],'86',$arr_ccy_defa),"</td></tr>
<tr><td>",lang(2606),':</td><td>',cms_form('select','per[fin_month]',(isset($per['fin_month']) ? $per['fin_month'] : $bsb['fin_month']),86,explode(',',lang(2614),12)),"</td></tr>";
	if (!cms_var("select 1 from bsb_category where pid=$bsb[pid] limit 1"))
		echo '<tr><td>',lang(2617),':</td><td>',cms_form('radio','per[cat]',($per['cat'] ? $per['cat'] : 2),' &nbsp; ',array(1=>'中文帐户','English A/C')),"</td></tr>";
	echo '<tr><td></td><td>',cms_form('submit','cmd',lang(2607),86),'</td></tr></table></form>';
}
function save_data(&$bsb,$per){
	$col=array('rep_round','ccy_list','fin_month');
	if ($per['ccy_default']<>$per['ccy'][0]){
		$ccy_list[]=$per['ccy_default'];
		foreach ($per['ccy'] as $k=>$v){
			if ($v<>$per['ccy_default']) $ccy_list[]=$v;
		}
	}else $ccy_list=$per['ccy'];
	$bsb['ccy_list']=implode(',',$ccy_list);
	$val=array($per['rep_round'],$bsb['ccy_list'],$per['fin_month']);
	$pid=$bsb['pid'];
	cms_sql('update','bsb_account',$col,$val,"where pid=$pid");
	if (($per['cat']==1 || $per['cat']==2) && !cms_var("select 1 from bsb_category where pid=$pid limit 1"))
		cms_run("insert into bsb_category(pid,cat,category) select $pid,cat,category from bsb_category where pid=$per[cat] order by 2");
	$arr=cms_row("select distinct ccy from bsb_book where pid=$pid",1);
	foreach ($arr as $ccy){
		if (!in_array($ccy,$ccy_list)) $err.=','.$bsb['ccy'][$ccy];
	}
	if ($err) $err='- '.lang(2615).': '.substr($err,1);
	return lang(2616)." $err";
}
?>
