<?php
include 'inc.page.php';
echo "<div style='max-width:600px;margin:0 auto'>";
@main($pin['dbL'],$start);
echo '</div>';
@down();

function main($dbL,$start){
	if ($dbL && cms_var("select 1 from bsb_ccy where ccy=1 and code='USD' limit 1")) return header('Location:home.php');//already v5.0
	nav1_guest();
	echo "<p class='bg box'><span class='green'>",lang(2401),"</span><br>",lang(2402,array("<b class='green'>inc.page.php</b>","<b class='green'>function db_conn()</b>","<b class='blue'>eng host user pass db</b>")),"</p>";
	if (!$dbL) return print('<p>'.lang(2403).'</p>');
	echo "<p class='ok'>",lang(2404),'</p>';
	if (cms_var('select 1 from bsb_cashbook_cd limit 1')) return print("<p class='err'>".lang(2405).'</p>');
	if (cms_var('select 1 from bsb_account limit 1')) main_upgrade($start);
	else main_new($start);
}
function main_upgrade($start=0){
	echo '<p>',lang(2406),'</p><p>',lang(2407,"<a href='http://topnew.net/sidu' target='_new'>SIDU</a>"),";<br><a href='?start=1'>",lang(2408),"</a></p>";
	if (!$start) return;
	$sql[]="ALTER TABLE bsb_account DROP COLUMN ccy_default";
	$sql[]="ALTER TABLE bsb_account CHANGE ccy_list ccy_list varchar(20) NOT NULL DEFAULT '1,2,3,4,5'";
	$sql[]="ALTER TABLE bsb_account CHANGE created created date";

	$sql[]="DROP TABLE bsb_ccy";
	$sql[]="CREATE TABLE bsb_ccy (ccy smallint NOT NULL DEFAULT 0 PRIMARY KEY,code char(3) NOT NULL DEFAULT '')";
	$sql[]="INSERT INTO bsb_ccy(ccy,code) VALUES (1,'USD'),(2,'EUR'),(3,'GBP'),(4,'AUD'),(5,'CNY'),(6,'CAD'),(7,'CHF'),(8,'DKK'),(9,'HKD'),(10,'JPY'),(11,'MOP'),(12,'NOK'),(13,'NZD'),(14,'SEK'),(15,'SGD')";

	$sql[]="ALTER TABLE bsb_book CHANGE credit credit varchar(9) NOT NULL DEFAULT '0'";
	$sql[]="ALTER TABLE bsb_book CHANGE debit debit varchar(9) NOT NULL DEFAULT '0'";
	$sql[]="ALTER TABLE bsb_book ADD COLUMN qty int NOT NULL DEFAULT 0";
	$sql[]="ALTER TABLE bsb_book CHANGE amt amt int NOT NULL DEFAULT 0";

	$sql[]="UPDATE bsb_book a SET a.ccy=(SELECT b.ccy FROM bsb_ccy b WHERE a.ccy=b.code)";
	$sql[]="ALTER TABLE bsb_book CHANGE ccy ccy smallint NOT NULL DEFAULT 1";

	$sql[]="ALTER TABLE bsb_category CHANGE cat_id cat varchar(9) NOT NULL DEFAULT '0'";
	$sql[]="ALTER TABLE bsb_term CHANGE dateto dateto date;";

	$sql[]="UPDATE bsb_account SET ccy_list='1,4,5,9' WHERE pid=1";
	$sql[]="UPDATE bsb_account SET ccy_list='1,2,3,4,5,6' WHERE pid=2";
	foreach ($sql as $v){
		$err=cms_err(cms_run($v));
		if ($err) return print("<p>$v</p><p class='err'>$err</p>");
	}
	echo "<p class='ok'>",lang(2409),"! - <a href='./'>",lang(2410),'</a></p>';
}
function main_uk($eng,$uk){
	if ($eng=='pgsql') return "CONSTRAINT $uk UNIQUE";
	return "UNIQUE KEY $uk";
}
function main_new($start=0){
	echo '<p>',lang(2411)," ...</p><p><a href='?start=1'>",lang(2412),'</a></p>';
	if (!$start) return;
	global $pin;
	$eng=$pin['eng'];
	if ($eng=='pgsql'){
		$int='bigint';
		$auto='serial';
	}else{
		$int='int unsigned';
		$auto=$int.' AUTO_INCREMENT';
	}
	$sql[]="CREATE TABLE bsb_account (
	pid int NOT NULL DEFAULT 0 PRIMARY KEY,
	ccy_list varchar(20) NOT NULL DEFAULT '1,2,3,4,5',
	fin_month smallint NOT NULL DEFAULT 0,
	rep_round smallint NOT NULL DEFAULT 0,
	cat_income varchar(15) NOT NULL DEFAULT '1',
	cat_invest varchar(15) NOT NULL DEFAULT '3',
	pass varchar(32) NOT NULL DEFAULT '',
	created date DEFAULT NULL,
	updated timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	sid varchar(32) NOT NULL DEFAULT '',
	ip $int NOT NULL DEFAULT 0,
	error smallint NOT NULL DEFAULT 0,
	".main_uk($eng,'sid')." (sid)
)";
	$sql[]="CREATE TABLE bsb_book (
	his_id $auto NOT NULL PRIMARY KEY,
	pid int NOT NULL DEFAULT 0,
	created timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	credit varchar(9) NOT NULL DEFAULT '0',
	debit varchar(9) NOT NULL DEFAULT '0',
	ccy smallint NOT NULL DEFAULT 1,
	amt int NOT NULL DEFAULT 0,
	qty int NOT NULL DEFAULT 0,
	remark varchar(50) NOT NULL DEFAULT ''
)";
	$sql[]="CREATE TABLE bsb_category (
	pid int NOT NULL DEFAULT 0,
	cat varchar(9) NOT NULL DEFAULT '0',
	category varchar(20) NOT NULL DEFAULT '',
	PRIMARY KEY (pid,cat),
	".main_uk($eng,'bsb_cat')." (pid,category)
)";
	$sql[]="CREATE TABLE bsb_ccy (ccy smallint NOT NULL DEFAULT 0 PRIMARY KEY,code char(3) NOT NULL DEFAULT '')";
	$sql[]="CREATE TABLE bsb_term (
	his_id int NOT NULL DEFAULT 0 PRIMARY KEY,
	dateto date DEFAULT NULL,
	rate_y smallint NOT NULL DEFAULT 0,
	remark varchar(50) NOT NULL DEFAULT ''
)";
//BensonBank 5.0 Sample Data: ###################
	$sql[]="INSERT INTO bsb_account(pid,ccy_list,fin_month,rep_round,cat_income,cat_invest,pass,created,updated,sid,ip,error) VALUES
(1,'1,4,5,9',0,0,1,3,'','2007-08-28','2008-08-28',1,0,0),(2,'1,2,3,4,5,6',0,0,1,3,'','2007-08-28','2008-08-28',2,0,0),
(100,'5,9,11,1',0,0,1,3,'0c4eff1e12a54b1971355765316b8701','2007-08-28','2007-08-28',100,0,0),(101,'1,2,3,6',0,0,1,3,'b630ab06203bec7aa80be97b27c6df16','2007-08-28','2007-08-28',101,0,0)";
	$sql[]="INSERT INTO bsb_ccy(ccy,code) VALUES (1,'USD'),(2,'EUR'),(3,'GBP'),(4,'AUD'),(5,'CNY'),(6,'CAD'),(7,'CHF'),(8,'DKK'),(9,'HKD'),(10,'JPY'),(11,'MOP'),(12,'NOK'),(13,'NZD'),(14,'SEK'),(15,'SGD')";
	$sql[]="INSERT INTO bsb_term(his_id,dateto,rate_y,remark) VALUES (1,'2009-01-01',120,'Withdraw'),(3,'2019-01-01',150,'CDOD'),(6,'2010-01-01',880,'DFEE')";
	$sql[]="INSERT INTO bsb_category(pid,cat,category) VALUES 
(1,1,'总收入'),(1,101,'工资'),(1,102,'收益'),
(1,2,'总支出'),(1,201,'伙食'),(1,202,'房租'),(1,203,'交通'),(1,204,'医疗'),(1,205,'教育'),(1,206,'交际'),(1,207,'税金'),
(1,3,'总资金'),(1,301,'活期'),(1,30101,'现金'),(1,30103,'农行活期'),(1,302,'定期'),(1,30201,'浦发理财'),(1,30202,'招行定期'),(1,303,'借贷'),(1,304,'公积'),(1,30401,'养老金'),(1,30402,'住房公积')";
	$sql[]="INSERT INTO bsb_category(pid,cat,category) VALUES 
(2,1,'Income'),(2,101,'Salary'),(2,102,'Profit'),
(2,2,'Expense'),(2,201,'Living'),(2,202,'Rent'),(2,203,'Travel'),(2,204,'Health'),(2,205,'Educate'),(2,206,'Other'),(2,207,'Tax'),
(2,3,'Invest'),(2,301,'Saving'),(2,30101,'Cash'),(2,30102,'HSBC'),(2,302,'Term'),(2,30201,'CITI'),(2,30202,'ING'),(2,303,'Loan'),(2,304,'Super')";
	$sql[]="INSERT INTO bsb_category SELECT 99+pid,cat,category from bsb_category where pid<3";
	$sql[]="INSERT INTO bsb_book(his_id,pid,created,credit,debit,ccy,amt,qty,remark) VALUES
(1,100,'2008-03-18',102,30201,5,60000,0,'阿弥陀佛红包'),
(2,100,'2008-03-18',101,30101,5,800000,0,''),
(3,100,'2008-03-18',30101,30202,5,500000,0,12566),
(4,100,'2008-03-28',30101,202,5,100000,0,''),
(5,101,'2008-03-18',101,30101,4,800000,0,''),
(6,101,'2008-03-18',30101,30201,4,500000,0,1568),
(7,101,'2008-03-28',30101,201,4,20000,0,'Food');";
	if ($eng=='pgsql') $sql[]="SELECT setval('bsb_book_his_id_seq',(SELECT MAX(his_id) FROM bsb_book)+1)";
	foreach ($sql as $v){
		$err=cms_err(cms_run($v));
		if ($err) return print("<p>$v</p><p class='err'>$err</p>");
	}
	echo "<p class='ok'>",lang(2413),"! - <a href='./'>",lang(2410),'</a></p>';
}
?>
