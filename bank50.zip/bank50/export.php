<?php
include 'inc.page.php';
@main($pin['bsb'],$cmd,$pin['eng']);
@down();

function main($bsb,$cmd,$eng){
	$pid=$bsb['pid'];
	$cols=array('pid','ccy_list','fin_month','rep_round','cat_income','cat_invest');
	$row=cms_row('select '.implode(',',$cols)." from bsb_account where pid=$pid");
	echo "<p>Export bsb_account for : $pid</p><p>",implode(', ',$cols),'<br>';
	foreach ($cols as $k) echo "'{$row[$k]}', ";
	echo '</p><p>Export bsb_category(cat,category)<br>';
	$arr=cms_row("select cat,category from bsb_category where pid=$pid order by 1",2);
	foreach ($arr as $k=>$v) echo "($k,'$v'), ";
	$cols=array('his_id','dateto','rate_y','remark');
	echo '</p><p>Export bsb_term(',implode(',',$cols),')';
	$rows=cms_rows("select a.* from bsb_term a,bsb_book b where a.his_id=b.his_id and b.pid=$pid order by 1");
	foreach ($rows as $row){
		echo '<br>';
		foreach ($cols as $k) echo $row[$k].'|';
	}
	$cols=array('his_id','created','debit','ccy','amt','qty','remark');
	echo '</p><p>Export bsb_book(',implode(',',$cols),") -- <a href='?cmd=all'>ALL</a> - <a href='?'>Year</a> - <a href='?cmd=m'>Month</a> - <a href='?cmd=d'>Day</a>";
	$rows=cms_rows("select * from bsb_book where pid=$pid order by created desc,his_id desc");
	if ($cmd=='m'){
		foreach ($rows as $row){
			if (!$row['remark']) $row['remark']='remark';
			$m=&$res[substr($row['created'],0,7)][$row['credit']][$row['debit']][$row['ccy']][$row['remark']];
			$m[0]+=$row['amt']; $m[1]+=$row['qty']; $m[2]=$row['his_id']; $m[3]=substr($row['created'],0,10);   
		}
	}elseif ($cmd=='d'){
		foreach ($rows as $row){
			if (!$row['remark']) $row['remark']='remark';
			$m=&$res[substr($row['created'],0,10)][$row['credit']][$row['debit']][$row['ccy']][$row['remark']];
			$m[0]+=$row['amt']; $m[1]+=$row['qty']; $m[2]=$row['his_id']; $m[3]=substr($row['created'],0,10);   
		}
	}elseif (!$cmd){
		foreach ($rows as $row){
			if (!$row['remark']) $row['remark']='remark';
			$m=&$res[substr($row['created'],0,4)][$row['credit']][$row['debit']][$row['ccy']][$row['remark']];
			$m[0]+=$row['amt']; $m[1]+=$row['qty']; $m[2]=$row['his_id']; $m[3]=substr($row['created'],0,10);   
		}
	}
	if ($cmd<>'all'){
		unset($rows);
		foreach ($res as $ymd=>$arr){
			foreach ($arr as $c=>$arr2){
				foreach ($arr2 as $d=>$arr3){
					foreach ($arr3 as $ccy=>$arr4){
						foreach ($arr4 as $rem=>$arr5) $rows[]=array('credit'=>$c,'debit'=>$d,'remark'=>($rem=='remark' ? '' : $rem),'ccy'=>$ccy,'amt'=>$arr5[0],'qty'=>$arr5[1],'his_id'=>$arr5[2],'created'=>$arr5[3]);
					}
				}
			}
		}
	}
	foreach ($rows as $i=>$row){
		echo '<br>';
		foreach ($cols as $k) echo $row[$k].'|';
	}
	echo '</p><p>TTL ',++$i,' rows Exported on ',date('Y-m-d H:i:s'),'</p>';
}
?>
