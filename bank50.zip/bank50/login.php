<?php
//this page doing login+reset password+apply member and logout
$pin['uppe']=-1;
include 'inc.page.php';
@main($u,$p,$p1,$p2,$tab);

function main($u,$p,$p1,$p2,$tab){
	if ($u=='logout'){
		global $pin;
		$u=$pin[0];
		if ($u){
			cms_sql('update','bsb_account',null,null,"sid='$u.$u',updated=now() where pid=$u");
			setcookie('BSB','',time()-1);
		}
	}
	$u=ceil($u); $p=trim($p);
	if ($u<1) $u='';
	if ($tab=='Login' && $u && $p){
		$err=valid_data_login($u,$p);
		if (!$err) return main_jump_login($u,$auto,$url);
	}
	uppe();
	$tabs=array('Login'=>lang(2505),'Apply'=>lang(2507),'PWD'=>lang(2506),'Change'=>lang(2513));
	echo cms_form(),"<div style='width:420px;margin:0 auto'>";
	nav1_guest($tab);
	echo "<ul class='tab'>";
	if (!$tab) $tab='Login';
	foreach ($tabs as $k=>$v) echo ($k==$tab ? "<li class='on'>$v</li>" : "<li><a href='login.php?tab=$k'>$v</a></li>");
	echo "</ul><div class='tab'>";
	if ($tab=='Login') main_form_login($u,$p,$err);
	elseif ($tab=='Apply') main_apply($u,$p,$p1);
	elseif ($tab=='PWD') main_pwd($u);
	elseif ($tab=='Change') main_change($u,$p,$p1,$p2);
	echo '</div></div></form>';
	down();
}
function main_jump_login($u){
	$ip=sprintf('%u',ip2long($_SERVER['REMOTE_ADDR']));
	$sid=rand_sid($u.date('Y-m-d H:i:s').$ip);
	cms_sql('update','bsb_account',null,null,"updated=now(),sid='$sid',ip=$ip,error=0 where pid=$u");
	$_COOKIE['BSB']=md5($sid).".$u";
	setcookie('BSB',$_COOKIE['BSB']);
	header('Location:home.php');
}
function main_form_login($u,$p,$err){
	echo '<p><b>',lang(2501),':</b></p>';
	if ($err) echo "<p class='err'>$err</p>";
	echo '<p>',lang(2502),':<br>',cms_form('text','u',$u,200),"</p>
<p>",lang(2503),':<br>',cms_form('password','p','',200),"</p>
<p>",cms_form('submit','cmd',lang(2505)),cms_form('hidden','tab','Login'),"
	&nbsp; <a href='login.php?tab=PWD&#38;u=$u'>",lang(2506),"</a></p><p>",lang(2526),"</p>
<p>",lang(2527),": <b class='green'>http://topnew.net/bank</b></p>
<p><i class='blue right'>Now: ",date('Y-m-d H:i:s'),"</i><b>",lang(2528),"</b></p><table width='100%'>";
	$rows=cms_rows("select pid,updated,ip from bsb_account order by 2 desc limit 5");
	foreach ($rows as $row) echo "<tr><td>$row[0]</td><td>",substr(long2ip($row[2]),0,5),"</td><td class='ar'>$row[1]</td></tr>";
	echo '</table>';
}
function valid_data_login($pid,$pwd){
	$user=cms_row("select * from bsb_account where pid='$pid' limit 1");
	if (!$user['pid']) return lang(2508);//98
	if ($user['error']==99) return lang(2509);
	if ($user['error']>9) return lang(2512);
	if ($user['pass']==md5(md5($pid.$pwd))) return;//login successful
	cms_sql('update','bsb_account','','',"updated=now(),error=error+1 where pid=$pid");
	return lang(2510,"<b class='green'>".(10-$user['error']).'</b>');//actually 1 time less than what displayed. but this is a very big hole if not
}
function main_pwd($u){
	if ($u && !cms_var("select 1 from bsb_account where pid=$u limit 1")) $err=lang(2508);
	echo cms_form('hidden','tab','PWD'),"<p><b>",lang(2506),"</b></p><p class='err'>$err</p>
		<p>",lang(2502),': ',cms_form('text','u',$u,80),' ',cms_form('submit','cmd',lang(2521),80),"</p>";
	if ($u && !$err) echo "<p>",lang(2519),":<br><i class='green'>update bsb_account set error=0,pass= '",md5(md5($u.'pass')),"' where pid=$u</i></p>
		<p>",lang(2520)," = <b class='red'>pass</b></p>";
}
function main_apply($u,$p,$p1){
	global $pin;
	if ($u){
		if (cms_var("select 1 from bsb_account where pid=$u limit 1") || cms_var("select 1 from per_person where pid=$u limit 1")) $err=lang(2515)."<br>";
		elseif ($u<102 || $u>999999) $err=lang(2502).": 100-999,999<br>";
		if (!$p) $err .=lang(2516);
		elseif ($p<>$p1) $err .=lang(2517);
	}
	echo '<p><b>',lang(2514),'</b></p>';
	if ($u && !$err){
		$col=array('pid','pass','created','sid','ip');
		$ip=sprintf('%u',ip2long($_SERVER['REMOTE_ADDR']));
		$val=array($u,md5(md5($u.$p)),date('Y-m-d'),rand_sid($u),$ip);
		cms_sql('insert','bsb_account',$col,$val);
		cms_run("insert into bsb_category select $u,cat,category from bsb_category where pid=".($pin['lang']=='cn' ? 1 : 2)." order by 2");
		echo "<p class='ok'>",lang(2518),"<br>",lang(2502)," : <b>$u</b><br>",lang(2503)," : <b>$p</b></p>";
	}else echo cms_form('hidden','tab','Apply'),"<p class='err'>$err</p>
<p>",lang(2502),': (100-999,999)<br>',cms_form('text','u',$u,200),"</p>
<p>",lang(2503),':<br>',cms_form('password','p','',200),"</p>
<p>",lang(2504),':<br>',cms_form('password','p1','',200),"</p>
<p>",cms_form('submit','cmd',lang(2507)),"</p>";
}
function main_change($u,$p,$p1,$p2){
	if ($u && $p){
		$p1=trim($p1); $p2=trim($p2);
		$err=valid_data_login($u,$p);
		if (!$err){
			if (!$p1) $err=lang(2523);
			elseif ($p1<>$p2) $err=lang(2524);
		}
	}
	echo '<p><b>',lang(2513),'</b></p>';
	if ($u && $p && $p1 && !$err){
		cms_sql('update','bsb_account','','',"pass='".md5(md5($u.$p1))."',error=0 where pid=$u");
		echo "<p class='ok'>",lang(2525),"</p>";
	}else echo cms_form('hidden','tab','Change'),"<p class='err'>$err</p>
<p>",lang(2502),':<br>',cms_form('text','u',$u,200),"</p>
<p>",lang(2503),':<br>',cms_form('password','p','',200),"</p>
<p>",lang(2522),':<br>',cms_form('password','p1','',200),"</p>
<p>",lang(2504),':<br>',cms_form('password','p2','',200),"</p>
<p>",cms_form('submit','cmd',lang(2513)),'</p>';
}
?>
