<?php
/*textar name	val	x			 y		style
	select name	val	size	 arr	style defa
	radio	 name	val	sepa	 arr	style	defa
	text	 name	val	size	 max	style
	pass	 name	val	size	 max	style
	submit name	val	size	 -		style
	hidden name	val	-			 -		-
	form	 name url method id		style*/
function cms_form($type='form',$name='',$val=null,$size='',$arr=null,$style='',$defa=null){
	if ($type=='form'){
		if (!$val) $val=array_pop(explode('/',$_SERVER['SCRIPT_NAME']));
		if ($val=='index.php') $val='./';
		return "<form action='$val' method='".($size ? $size : 'post')."'".($name ? " name='$name'" : '').($arr ? " id='$arr'" : '').($style ? " $style" : '').'>';
	}
	if ($val && !is_array($val)) $val=cms_html8($val);
	$style=($style ? " $style" : '');
	$style_arr=explode("style='",$style,2);
	if ($type=='textarea'){
		if ($size || $arr){
			if ($size) $str="width:$size".'px;';
			if ($arr) $str.="height:$arr".'px;';
			if ($style_arr[1]) $style=$style_arr[0]."style='$str".$style_arr[1];
			else $style=" style='$str'".$style;
		}
		return "<textarea name='$name'$style>$val</textarea>";
	}
	if ($size && $type<>'radio' && $type<>'checkbox'){
		if ($style_arr[1]) $style=$style_arr[0]."style='width:$size"."px;$style_arr[1]";
		else $style=" style='width:$size"."px'$style";
	}
	$style="name='$name'$style";
	if ($type=='select'){
		$str="<select size='1' $style>";
		foreach ($defa as $k=>$v)
			$str .="<option value='$k'".(in_array($k,$val) || $k==$val ? " selected='selected'" : '').">$v</option>";
		foreach ($arr as $k=>$v)
			$str .="<option value='$k'".(in_array($k,$val) || $k==$val ? " selected='selected'" : '').">$v</option>";
		return $str.'</select>';
	}
	if ($type=='radio' || $type=='checkbox'){
		if (!$size) $size=' ';//sepa
		foreach ($defa as $k=>$v)
			$str .="<input type='$type' $style value='$k'".($k==$val || in_array($k,$val) ? " checked='checked'" : '')."> $v$size";
		foreach ($arr as $k=>$v)
			$str .="<input type='$type' $style value='$k'".($k==$val || in_array($k,$val) ? " checked='checked'" : '')."> $v$size";
		return substr($str,0,0-strlen($size));
	}
	return "<input type='$type' $style value='$val'".(is_numeric($arr) ? " maxlength='$arr'" : '').'>';
}
function cms_html8($str=''){return htmlspecialchars($str,ENT_QUOTES,'UTF-8');}
function swap(&$a,&$b){$t=$a;$a=$b;$b=$t;}
function cms_strip($val,$trim=0,$tag=0,$slash=0){//tag==1,0 or <p><b>...
	if (is_array($val)){
		foreach ($val as $k=>$v) $val[$k]=cms_strip($v,$trim,$tag,$slash);
	}else{
		if ($tag)	$val=strip_tags($val,($tag==1 ? '' : $tag));
		if ($slash==='sql') $val=str_replace(array('#','--',';','/*','\'','"','\\'),'',$val);//heck free+no slash
		elseif ($slash) $val=stripslashes($val);
		if ($trim) $val=trim($val);
	}
	return $val;
}
function rand_sid($sid){
	$sid=md5($sid.date('Y-m-d H:i:s').rand());
	if (cms_var("select 1 from bsb_account where sid='$sid' limit 1")) return rand_sid($sid);
	return $sid;
}
function lang($id,$to){
	global $Dict;
	if (!isset($to)) return $Dict[$id];
	if (!is_array($to)) return str_replace('%0%',$to,$Dict[$id]);
	foreach ($to as $k=>$v) $tr[]="%$k%";
	return str_replace($tr,$to,$Dict[$id]);
}
//HTML---------------------------
function img($src,$w=16,$h=16){return "<img src='img/$src' width='$w' height='$h' alt=''>";}
function cat_bala($pid,&$bala,$row,$is_c,$cd,&$ttl_c,&$ttl_d){
	if (!isset($bala[$row['ccy']][$row[$cd]])){
		$tmp=cms_var("select sum(if(credit={$row[$cd]},amt,0-amt)) from bsb_book where pid=$pid and ccy='$row[ccy]'
		and (credit like '{$row[$cd]}%' or debit like '{$row[$cd]}%')
		and (created<'$row[created]' or (created='$row[created]' and his_id<$row[his_id]))");
		$bala[$row['ccy']][$row[$cd]]=$tmp;
	}
	$bala[$row['ccy']][$row[$cd]] +=($is_c ? $row['amt'] : 0-$row['amt']);
	if ($is_c) $ttl_c +=$row['amt'];
	else $ttl_d +=$row['amt'];
}
function main_amt($amt,$class){
	if (!$class) $class=($amt<0 ? 'red' : 'green');
	return "<td class='ar".($class<>-1 ? ' '.$class : '')."'>".number_format($amt/100,2).'</td>';
}
function cout_num($x,$is_inc,$bg){//bg:1,-1
	global $pin;
	$round=$pin['bsb']['rep_round'];
	$x=round($x/100,$round);
	if (!$is_inc) $x *=-1;
	if ($x<0) $class='red ';
	if ($bg==-1) $class .='bg0';
	elseif ($bg) $class .='bg1 b';
	if ($class) $class=" class='".trim($class)."'";
	echo "<td$class>",number_format($x,$round),"</td>";
}
function cout_diary_list($cat,$sql){
	global $pin;
	$bsb=$pin['bsb'];
	$Inc=explode(',',$bsb['cat_income']);
	$Inv=explode(',',$bsb['cat_invest']);
	$CAT=cms_row("select cat,category from bsb_category where pid=".$bsb['pid'],2);
	if ($cat=='date' || $cat=='his') $sql="select * from bsb_book where pid=$bsb[pid]
		order by ".($cat=='date' ? 'created desc,' : '')."his_id desc limit 6";
	elseif (count($cat)==1){
		$show_cd=1; $len=strlen($cat[0]); $cat1=substr($cat[0],0,1);
	}
	echo "<table class='grid'><tr class='bg1'><td>",lang(608),"</td>
		<td colspan='2'>",($show_cd ? lang(610) : lang(613)),"</td>
		<td colspan='2'>",($show_cd ? lang(620) : lang(614)),"</td><td>",lang(611),"</td>";
	if ($show_cd) echo "<td class='ar'>",lang(613),"</td><td class='ar'>",lang(614),"</td>";
	echo "<td class='ar'>",($show_cd ? lang(615) : lang(622)),"</td><td>",lang(612),"</td><td class='ar'>QTY</td><td></td></tr>";
	$rows=cms_rows($sql);
	foreach ($rows as $row){
		$date=substr($row['created'],0,10);
		if ($show_cd){
			$is_inv=in_array($cat1,$Inv); $is_inc=in_array($cat1,$Inc);
			$is_c=($row['credit']==$cat[0] || substr($row['credit'],0,$len)==$cat[0])+0;
			if (!$is_c) swap($row['credit'],$row['debit']);
			cat_bala($bsb['pid'],$bala,$row,$is_c,'credit',$ttl_c,$ttl_d);
		}
		echo "<tr><td><a href='search.php?fm=$date&#38;to=$date' title='",lang(603),"'>$date</a></td>
<td><a href='add.php?rec[credit]=$row[credit]&#38;rec[ccy]=$row[ccy]&#38;rec[debit]=$row[debit]&#38;rec[remark]=$row[remark]' class='green' title='",lang(602),"'>$row[credit]</a></td>
<td><a href='search.php?cat[0]=$row[credit]&#38;ccy=$row[ccy]' class='green' title='",lang(603),"'>",$CAT[$row['credit']],"</a></td>
<td>$row[debit]</td><td><a href='search.php?cat[0]=$row[debit]&#38;ccy=$row[ccy]' title='",lang(603),"'>",$CAT[$row['debit']],"</a></td><td>";
		if ($row['remark']) echo "<a href='search.php?ccy=$row[ccy]&#38;rem=$row[remark]' class='green' title='",lang(603),"'>$row[remark]</a>";
		echo '</td>';
		if (!$show_cd) echo main_amt($row['amt']);
		else{
			if ($is_inc){
				if ($is_c) echo main_amt($row['amt'],-1),'<td></td>';
				else echo '<td></td>',main_amt(0-$row['amt'],'red');
			}elseif ($is_inv){
				if (!$is_c) echo main_amt($row['amt'],'green'),'<td></td>';
				else echo '<td></td>',main_amt(0-$row['amt'],'blue');
			}else{//exp
				if ($is_c) echo main_amt($row['amt'],'red'),'<td></td>';
				else echo '<td></td>',main_amt(0-$row['amt'],-1);
			}
			if ($is_inv) echo main_amt(0-$bala[$row['ccy']][$row['credit']]);
			else echo main_amt($bala[$row['ccy']][$row['credit']]);
			if (substr($row['credit'],0,1)==substr($row['debit'],0,1) && substr($row['debit'],0,$len)==$cat[0]){
				echo "<td>$row[ccy]</td><td></td></tr><tr><td></td>
<td><a href='search.php?cat[0]=$row[debit]&#38;ccy=$row[ccy]' class='green'>$row[debit]</a></td>
<td><a href='search.php?cat[0]=$row[debit]&#38;ccy=$row[ccy]&#38;rem=$row[remark]' class='green'>",$CAT[$row['debit']],"</a></td>
<td><a href='search.php?cat[0]=$row[credit]&#38;ccy=$row[ccy]'>$row[credit]</a></td>
<td><a href='search.php?cat[0]=$row[credit]&#38;ccy=$row[ccy]&#38;rem=$row[remark]'>",$CAT[$row['credit']],"</a></td>
<td>$row[remark]</td>";
				cat_bala($bsb['pid'],$bala,$row,!$is_c,'debit',$ttl_c,$ttl_d);
				if ($is_inc){
					if (!$is_c) echo main_amt($row['amt'],-1),"<td></td>";
					else echo '<td></td>',main_amt(0-$row['amt'],'red');
				}elseif ($is_inv){
					if ($is_c) echo main_amt($row['amt'],'green'),'<td></td>';
					else echo '<td></td>',main_amt(0-$row['amt'],'blue');
				}else{//exp
					if (!$is_c) echo main_amt($row['amt'],'red'),'<td></td>';
					else echo '<td></td>',main_amt(0-$row['amt'],-1);
				}
				if ($is_inv) echo main_amt(0-$bala[$row['ccy']][$row['debit']]);
				else echo main_amt($bala[$row['ccy']][$row['debit']]);
			}
		}
		echo "<td>{$bsb[ccy][$row[ccy]]}</td><td class='ar'>";
		if ($row['qty']){
			$c1=substr($cat[0],0,1);
			if ((!$show_cd && substr($row['credit'],0,1)==9) || (
			$show_cd && (($c1==9 && $is_c) || ($c1<>9 && !$is_c)))){
				echo "<i class='red'>-$row[qty]</i>";
				$ttl_q-=$row['qty'];
			}else{
				echo $row['qty']; $ttl_q+=$row['qty'];
			}
		}
		echo "</td><td><a href='add.php?his=$row[his_id]' class='green none'>".lang(616)."</a></td></tr>";
	}
	if ($show_cd){
		echo "<tr class='bg1'><td colspan='6'>",lang(617),'</td>';
		if ($is_inv) echo main_amt($ttl_d),main_amt(0-$ttl_c),main_amt($ttl_d-$ttl_c);
		else echo main_amt($ttl_c),main_amt(0-$ttl_d),main_amt($ttl_c-$ttl_d);
		echo "<td></td><td class='ar'>$ttl_q</td><td></td></tr>";
	}
	echo '</table>';
}
function main_header($ccy,$len,$CAT,$field){
	echo "<tr class='bg1'><td class='blue'>$ccy</td>";
	foreach ($CAT as $k=>$v){
		if ($len==1 && in_array($k,$field)) echo "<td>$v</td>";
		elseif ($len==3){
			$f=0;
			foreach ($v as $k1=>$v1){if ($k1<>$k && in_array($k1,$field)){
				echo "<td>$v1</td>"; $f=1;
			}}
			if ($f || in_array($k,$field)) echo "<td class='blue'>{$v[$k]}</td>";
		}elseif ($len==5){
			$f0=0;
			foreach ($v as $k1=>$v1){
				$f=0;
				foreach ($v1 as $k2=>$v2){if ($k2<>$k1 && $k2<>$k && in_array($k2,$field)){
					echo "<td class='orange'>$v2</td>"; $f=1; $f0=1;
				}}
				if ($k1<>$k && ($f || in_array($k1,$field))){
					echo "<td>{$v1[$k1]}</td>"; $f0=1;
				}
			}
			if ($f0 || in_array($k,$field)) echo "<td class='blue'>{$v[$k][$k]}</td>";
		}
	}
	if ($ccy) echo '<td>*</td>';
	echo '</tr>';
}
function get_CAT($pid,$len,$sql_cat){
	$sql="select cat,category from bsb_category where pid=$pid $sql_cat and length(cat)<=$len order by 1";
	$rows=cms_rows($sql);
	foreach ($rows as $row){
		if ($len==1) $CAT[$row[0]]=$row[1];
		elseif ($len==3) $CAT[substr($row[0],0,1)][$row[0]]=$row[1];
		else $CAT[substr($row[0],0,1)][substr($row[0],0,3)][$row[0]]=$row[1];
	}
	return $CAT;
}
function main_data_5($is_inc,$data,$k,$v,$field,&$TTL,$sumUP,$bala,&$line,&$strAvg,$avgTTL){
	foreach ($v as $k1=>$v1){
		$sum5=0; $f=0;
		foreach ($v1 as $k2=>$v2){if ($k2<>$k1 && $k2<>$k && in_array($k2,$field)){
			if ($sumUP) $TTL[$k2] +=$data[$k2];
			elseif (isset($bala)) $data[$k2] +=$bala[$k2];
			$sum5 +=$data[$k2]; cout_num($data[$k2],$is_inc,-1);
			$f=1; $f0=1;
			if (isset($strAvg)) $strAvg .=cout_pct($data[$k2],$avgTTL,$is_inc);
		}}
		if ($k1<>$k && ($f || in_array($k1,$field))){
			if ($sumUP) $TTL[$k1] +=$data[$k1];
			elseif (isset($bala)) $data[$k1] +=$bala[$k1];
			$sum5 +=$data[$k1]; $sum3 +=$sum5;
			cout_num($sum5,$is_inc);
			$f0=1;
			if (isset($strAvg)) $strAvg .=cout_pct($sum5,$avgTTL,$is_inc);
		}
	}
	if ($sumUP) $TTL[$k] +=$data[$k];
	$sum3 +=$data[$k];
	if (isset($bala)) $sum3 +=$bala[$k];
	if ($f0 || in_array($k,$field)){
		$line +=$sum3; cout_num($sum3,$is_inc,1);
		if (isset($strAvg)) $strAvg .=cout_pct($sum3,$avgTTL,$is_inc);
	}
}
function init_pin($lang){
	global $pin;
	$pin['dbL']=db_conn($pin['eng']);
	$pin['url']=$url=array_pop(explode('/',$_SERVER['SCRIPT_NAME']));
	if (!$pin['dbL']){
		if ($url<>'index.php') die('Err: Cannot connect to database, please check file <b>inc.page.php</b> func <b>db_conn()</b>');
	}else $pin[0]=get_pid();
	init_lang($pin,$lang);
	if (!$pin[0]){
		if ($url<>'index.php' && $url<>'login.php') header('Location:login.php');
		return;
	}
	$pin['bsb']=cms_row("select * from bsb_account where pid=$pin[0]");
	$pin['bsb']['ccy']=cms_row("select ccy,code from bsb_ccy",2);
}
function get_pid(){
	$ses=explode('.',$_COOKIE['BSB'],2);//sid.pid
	if (!$ses[0]) return 0;
	$pid=ceil($ses[1]);
	if ($pid){
		$row=cms_row("select pid,updated,sid,ip,error from bsb_account where pid=$pid");
		if ($row['pid'] && $row['error']<10){
			$ip=sprintf('%u',ip2long($_SERVER['REMOTE_ADDR']));
			if ($row['ip']==$ip && time()-strtotime($row['updated'])<60*60) return $pid;//within 1 hour
		}
	}
	setcookie('BSB','',time()-1);
}
function init_lang(&$pin,$lang){
	if ($lang) $pin['lang']=$lang;
	if (!$pin['lang']) $pin['lang']=$_COOKIE['BSBlang'];
	if (!$pin['lang']) $pin['lang']='en';
	if ($pin['lang']<>$_COOKIE['BSBlang']) setcookie('BSBlang',$pin['lang'],time()+31536000);
}
function uppe($title=''){
	if (!$title) $title='本生理财: BenSonBank v5.0 - Cash Management System - topnew.net/bank - 2013-10-28';
	echo "<!DOCTYPE html>\n<html>\n<head>\n<meta charset='utf-8'>\n<title>$title</title>
<meta name='author' content='Topnew Geo'>
<meta name='viewport' content='width=device-width,initial-scale=1'>
<link rel='stylesheet' media='all' type='text/css' href='img/my.css'>
<link rel='shortcut icon' href='img/bsb.png'>
<script type='text/javascript' src='img/my.js'></script>
</head>
<body><div id='page'><div id='main'>";
}
function down(){
	global $pin;
	if (!in_array($pin['url'],array('login.php','index.php'))) nav1();
	echo '</div><!--main--></div><!--page-->';
	echo '</body></html>';
}
function nav1(){//need update
	echo "<div id='head'><a href='home.php'>",lang(601),"</a> -
<a href='add.php'>",lang(602),"</a> -
<a href='search.php'>",lang(603),"</a> -
<a href='cat.php'>",lang(604),"</a> -
<a href='my.php'>",lang(605),"</a> -
<a href='export.php'>",lang(606),"</a> -
<a href='login.php?u=logout'>",lang(607),"</a></div><!--head-->";
}
function nav1_guest($tab){
	if ($tab) $tab="&#38tab=$tab";
	echo "<div style='top:0;padding:9px'><span class='right'>
	<a href='?lang=en$tab'>English</a> - <a href='?lang=cn$tab'>中文</a></span>",
	img('bsb.png')," &nbsp; <b class='blue'>",lang(621),"</b></div>";
}
//db func copied from topnew cms===================================
function cms_err($sth=null){
	global $pin;
	if (!isset($sth)) $sth=$pin['dbL'];
	$err=$sth->errorCode();
	if (!$err || $err=='00000') return;
	$err=$sth->errorInfo();
	return "Err $err[1] $err[2]";
}
function cms_last_id(){
	global $pin;
	if ($pin['eng']=='pgsql') return $pin['pg_insert_id'];
	return $pin['dbL']->lastInsertId();
}
//pk=0 return one row
//pk=1 return arr[]=row[0]
//pk=2 return arr[row[0]]=row[1]
//pk=3 return one var
//pk=4 return all rows
//pk=k return arr[k]=row
function cms_row($sql='',$pk=0,$para=array()){
	if (!$sql) return;
	$sth=cms_run($sql,$para);
	if (!$pk) return $sth->fetch();
	if ($pk==3){
		$row=$sth->fetch(PDO::FETCH_NUM); return $row[0];
	}
	if ($pk==1){
		$rows=$sth->fetchAll(PDO::FETCH_NUM);
		foreach ($rows as $row) $arr[]=$row[0];
	}elseif ($pk==2){
		$rows=$sth->fetchAll(PDO::FETCH_NUM);
		foreach ($rows as $row) $arr[$row[0]]=$row[1];
	}elseif ($pk==4){
		$arr=$sth->fetchAll();
	}else{
		$rows=$sth->fetchAll(PDO::FETCH_ASSOC);
		foreach ($rows as $row) $arr[$row[$pk]]=$row;
	}
	return $arr;
}
function cms_rows($sql='',$para=array()){return cms_row($sql,4,$para);}
function cms_var($sql='',$para=array()){return cms_row($sql,3,$para);}
function cms_sql($cmd='',$tab='',$col=null,$val=null,$where=''){
	if ($col && isset($val) && !is_array($val)){
		$col=array($col); $val=array($val);
	}
	if (isset($val) && is_array($val)){
		foreach ($col as $k=>$v){
			$x=':'.$v; $y=$val[$k];
			$para[$x]=$y; $ins[]=$x; $upd[]="$v=$x";
		}
	}
	if ($cmd=='save') $cmd=(cms_var("SELECT 1 FROM $tab $where LIMIT 1") ? 'update' : 'insert');
	if ($cmd=='insert' || $cmd=='replace') $sql=strtoupper($cmd)." INTO $tab(".implode(',',$col).")\nVALUES(".implode(',',$ins).')';
	elseif ($cmd=='delete') $sql="DELETE FROM $tab\n$where";
	elseif ($cmd=='update') $sql="UPDATE $tab\nSET ".implode(',',$upd)."\n$where";
	if ($cmd=='insert' && substr($where,0,12)=='cms_last_id:') $pg_insert_id=substr($where,12);
	return cms_run($sql,$para,$pg_insert_id);
}
function cms_run($sql='',$para=array(),$pg_insert_id=''){
	global $pin;
	if ($pin['eng']=='pgsql' && $pg_insert_id) $sql.=' returning '.$pg_insert_id;
	else $pg_insert_id=0;
	$sth=$pin['dbL']->prepare($sql);
	$sth->execute($para);
	if ($pg_insert_id){
		$row=$sth->fetch(PDO::FETCH_NUM);
		$pin['pg_insert_id']=$row[0];
	}
	return $sth;
}
?>
