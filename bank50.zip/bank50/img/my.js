function seekDate(a,b){
	document.searchform.fm.value=a;document.searchform.to.value=b;
}
