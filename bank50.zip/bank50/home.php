<?php
include 'inc.page.php';
@main($pin['bsb'],$p,$i,$t);
@down();

function main($bsb,$p,$i,$t){
	echo '<p>',lang(618)," <b class='green'>$bsb[pid]</b></p>";
	if (!$bsb['cat_income']) echo "<p class='red'>",lang(2301),": <a href='cat.php'>",lang(2302),'</a></p>';
	main_future($bsb);
	if (!$bsb['cat_invest']) echo "<p class='red'>",lang(2303),": <a href='cat.php'>",lang(2302),'</a></p>';
	else main_balance($bsb,1);
	main_balance($bsb);
	echo '<p>',lang(619),'</p>';
	cout_diary_list('date');
	main_calc($p,$i,$t);
}
function main_calc($p,$i,$t){
	if ($p<1) $p=1000;
	if ($i<0.000001) $i=5;
	if ($t<0.002) $t=1;
	$amt=$p*$i/100*$t;
	$ttl=$amt+$p;
	echo cms_form(),"<p>\$ ",cms_form('text','p',$p,80),' * ',cms_form('text','i',$i,50,'',"title='Yearly rate'"),' %Y * ',
		cms_form('select','t',$t,100,array('Term','1 Year','2 Years','3 Years','4 Years','5 Years',10=>'10 Years','0.083333333'=>'1 Month','0.166666667'=>'2 Months','0.25'=>'3 Months','0.333333333'=>'4 Months','0.416666667'=>'5 Months','0.5'=>'6 Months','0.583333333'=>'7 Months','0.666666667'=>'8 Months','0.75'=>'9 Months','0.833333333'=>'10 Months','0.916666667'=>'11 Months','0.002737911'=>'1 Day')),' ',
		cms_form('submit','cmd','Go'),'<br>= ',number_format($p,2),' + ',number_format($amt,2),' = ',number_format($ttl,2),'</p></form>';
}
function main_balance($bsb,$invOnly=0){
	$pid=$bsb['pid'];
	$len=($invOnly ? 5 : 3);
	$sql="select ccy,substr(credit,1,$len),sum(amt) from bsb_book where pid=$pid group by 1,2";
	$rows=cms_rows($sql);
	foreach ($rows as $row) $data[$row[0]][$row[1]]=$row[2];
	$sql="select ccy,substr(debit,1,$len),sum(amt) from bsb_book where pid=$pid group by 1,2";
	$rows=cms_rows($sql);
	foreach ($rows as $row) $data[$row[0]][$row[1]]-=$row[2];
	$inv=explode(',',$bsb['cat_invest']);
	$CAT=get_CAT($pid,$len);
	echo '<p>',($invOnly ? lang(2313) : lang(2314)),'</p>';
	$Inc=explode(',',$bsb['cat_income']);
	echo "<table class='grid ar pre'>";
	foreach ($data as $ccy=>$CCY){
		$field=array();
		foreach ($CCY as $k=>$v){
			$k1=substr($k,0,1);
			if (!in_array($k,$field) && (($invOnly && in_array($k1,$inv)) 
			|| (!$invOnly && !in_array($k1,$inv))) && $v) $field[]=$k;
		}
		main_header($bsb['ccy'][$ccy],$len,$CAT,$field);
		main_data($len,$CAT,$CCY,$field,$Inc);
	}
	echo '</table>';
}
function main_data($len,$CAT,$data,$field,$Inc){
	echo "<tr class='bg1'><td></td>";
	foreach ($CAT as $k=>$v){
		$is_inc=in_array(substr($k,0,1),$Inc);
		main_data_5($is_inc,$data,$k,$v,$field);
	}
	echo '</tr>';
}
function main_future($bsb){
	$sort=($_GET['sort'] ? $_GET['sort'] : 'dateto,ccy');
	echo "<p>",lang(2307,date('Y-m-d')),"</p><table class='grid'><tr class='bg1' title='",lang(2308),"'>
<td><a href='?sort=cat,dateto'>",lang(609),"</a></td>
<td><a href='?sort=category,dateto'>",lang(610),"</a></td>
<td><a href='?sort=remark,dateto'>",lang(611),"</a></td>
<td><a href='?sort=created,dateto'>",lang(2309),"</a></td>
<td><a href='home.php'>",lang(2310),"</a></td>
<td><a href='?sort=rem,dateto'>",lang(2311),"</a></td>
<td><a href='?sort=rate_y,ccy'>",lang(2312),"</a></td>
<td><a href='?sort=ccy,dateto'>",lang(612),"</a></td>
<td class='ar'><a href='home.php?sort=ccy,amt'>",lang(615),"</a></td><td></td></tr>";
	$sql="select a.*,b.category,c.remark rem,c.dateto,c.rate_y from bsb_book a,bsb_category b,bsb_term c
		where a.his_id=c.his_id and a.debit=b.cat and a.pid=b.pid and a.pid=$bsb[pid] order by $sort";
	$rows=cms_rows($sql);
	$today=date('Y-m-d'); $thisM=date('Y-m');
	foreach ($rows as $row){
		if (!$row['remark']) $amt=0-$row['amt'];
		else $amt=cms_var("select sum(if(credit=$row[debit],amt,0-amt)) from bsb_book where pid=$row[pid] and
			remark='".str_replace("'","''",$row['remark'])."' and (debit=$row[debit] or credit=$row[debit])");
		if ($amt){
			$dfm=substr($row['created'],0,10);
			$class='';
			if ($row['dateto']<=$today) $class=" class='red'";
			elseif (substr($row['dateto'],0,7)==$thisM) $class=" class='green'";
			echo "<tr><td><a href='add.php?rec[debit]=$row[debit]&#38;rec[ccy]=$row[ccy]' title='",lang(602),"' class='green'>$row[debit]</a></td>
<td><a href='search.php?cat[0]=$row[debit]&#38;ccy=$row[ccy]' title='",lang(603),"'>$row[category]</a></td>
<td><a href='search.php?cat[0]=$row[debit]&#38;ccy=$row[ccy]&#38;rem=$row[remark]' title='",lang(603),"'>$row[remark]</a></td>
<td",($dfm>$today ? " class='red'" : ''),'>',substr($row['created'],0,10),"</td><td$class>$row[dateto]</td><td>$row[rem]</td>",
main_amt($row['rate_y']),"<td>{$bsb[ccy][$row[ccy]]}</td>",main_amt(0-$amt),"
<td><a href='add.php?his=$row[his_id]' class='green'>",lang(616),'</a></td></tr>';
		}
	}
	echo '</table>';
}
?>
