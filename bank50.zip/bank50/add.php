<?php
include 'inc.page.php';
@main($pin['bsb'],$rec,$cmd);
@down();

function main($bsb,$rec,$cmd){
	$pid=$bsb['pid'];
	if (isset($_GET['his'])) $rec=init_data($pid,$_GET['his']);
	elseif ($cmd==lang(2002)) $rec['his_id']=0;//copy
	elseif ($cmd==lang(2017)) unset($rec);//reset
	elseif ($cmd) $err=save_data($pid,$rec,$cmd);
	main_form($bsb,$rec,$err);
	echo lang(619),': ',lang(618)," <b class='green'>$pid</b>";
	cout_diary_list('his');
}
function save_data($pid,&$rec,$cmd){
	if (!$rec['credit']) return lang(2003);
	if (!$rec['debit']) return lang(2004);
	if ($rec['credit']==$rec['debit']) return lang(2005);
	$his_id=ceil($rec['his_id']);
	if ($his_id){
		$row=cms_row("select * from bsb_book where his_id=$his_id");
		$his_id=$row['his_id'];
		if ($his_id && $row['pid']<>$pid) return lang(2006);
	}
	if ($cmd==lang(2018)){//save
		$rec['amt']=round($rec['amt'],2);
		if ($rec['amt']==0.00) return lang(2007);
		if ($rec['amt']<0){
			swap($rec['credit'],$rec['debit']); $rec['amt'] *= -1;
		}
		if ($rec['dateto'] && substr($rec['created'],0,10)>$rec['dateto']) return lang(2008);
		$rec=cms_strip($rec,1,1,'sql');
		if ($rec['remark']==lang(611)) $rec['remark']='';
		$col=array('pid','created','credit','debit','remark','ccy','amt','qty');
		$val=array($pid,$rec['created'],ceil($rec['credit']),ceil($rec['debit']),$rec['remark'],ceil($rec['ccy']),$rec['amt']*100,ceil($rec['qty']));
		if ($his_id) cms_sql('update','bsb_book',$col,$val,"where his_id=".$his_id);
		else{
			cms_sql('insert','bsb_book',$col,$val,'cms_last_id:his_id');
			$his_id=cms_last_id();
		}
		cms_sql('delete','bsb_term',null,null,"where his_id=$his_id");
		if ($rec['dateto']){
			if ($rec['rem']==lang(2014)) $rec['rem']='';
			$col=array('his_id','remark','dateto','rate_y');
			$val=array($his_id,$rec['rem'],$rec['dateto'],$rec['rate_y']*100);
			cms_sql('insert','bsb_term',$col,$val);
		}
	}elseif ($cmd==lang(2015)){//delete
		if (!$his_id || $pid<>$row['pid'] || !$row['pid']) return lang(2006);
		cms_sql('delete','bsb_book',null,null,"where his_id=$his_id");
		cms_sql('delete','bsb_term',null,null,"where his_id=$his_id");
	}
	$rec['amt']=$rec['his_id']=$rec['remark']=$rec['rem']=$rec['dateto']=$rec['rate_y']='';
	echo "<p class='green'>",lang(2001),"</p>";
}
function init_data($pid,$his){
	$row=cms_row("select * from bsb_book where his_id=$his");
	if ($row['pid']<>$pid) return;
	$rem=cms_row("select * from bsb_term where his_id=$row[his_id]");
	if ($rem['his_id']){
		$row['rem']=$rem['remark']; $row['dateto']=$rem['dateto']; $row['rate_y']=$rem['rate_y']/100;
	}
	$row['amt'] /=100;
	return $row;
}
function main_form($bsb,$rec,$err){
	$arr_cat=cms_row("select cat,category from bsb_category where pid=$bsb[pid] order by 1",2);
	foreach ($arr_cat as $k=>$v) $arr_cat[$k]="$k - $v";
	$arr=explode(',',$bsb['ccy_list']);
	foreach ($arr as $v) $arr_ccy[$v]=$bsb['ccy'][$v];
	echo cms_form(),"<table class='bg' style='border:solid 1px #cca' cellspacing='5'>
<tr><td>",cms_form('select','rec[credit]',$rec['credit'],220,$arr_cat,'',array(lang(2009))),'</td><td>',
	cms_form('select','rec[debit]',$rec['debit'],165,$arr_cat,'',array(lang(2010))),
	cms_form('select','rec[ccy]',$rec['ccy'],55,$arr_ccy),"</td><td>",
	cms_form('text','rec[amt]',$rec['amt'],60,'',"class='ar' title='".lang(2011)."'"),"</td></tr>
<tr><td class='ar'>",lang(608),': ',cms_form('text','rec[created]',($rec['created'] ? $rec['created'] : date('Y-m-d H:i:s')),132,19),"</td>
	<td class='ar small'>Q ",cms_form('text','rec[qty]',$rec['qty'],30,'',"title='QTY'"),' ',
	cms_form('text','rec[remark]',($rec['remark'] ? $rec['remark'] : lang(611)),155),"</td><td>";
	if ($rec['his_id']) echo cms_form('submit','cmd',lang(2015),65,'',"onclick=\"return confirm('".lang(2016)."?')\""),cms_form('submit','cmd',lang(2002),56);
	else echo cms_form('submit','cmd',lang(2017),65);
	echo "</td></tr>
<tr><td title='YYYY-mm-dd' class='ar'>",lang(2012),': ',cms_form('text','rec[dateto]',$rec['dateto'],132,10),"</td>
	<td class='ar small'>% ",cms_form('text','rec[rate_y]',$rec['rate_y'],30,'',"title='".lang(2013)."'"),' ',cms_form('text','rec[rem]',($rec['rem'] ? $rec['rem'] : lang(2014)),155),"</td>
	<td>",cms_form('submit','cmd',lang(2018),65),"</td></tr>
</table>",cms_form('hidden','rec[his_id]',$rec['his_id']),"</form>
<p class='err'>$err</p>
<p>",lang(2019),'</p><p>',lang(2020),'</p>';
}
?>
