<?php
extract($_POST); extract($_GET);
date_default_timezone_set('UTC');
include 'inc.func.php';
@init_pin($lang);
if (is_file("inc.lang.$pin[lang].php")) include "inc.lang.$pin[lang].php";
else include 'inc.lang.en.php';
if ($pin['uppe']<>-1) @uppe();

function db_conn(&$eng){//pls update following 5 values
	$eng='mysql';//mysql|pgsql|sqlite|cubrid--fully tested with mysql|pgsql,other not yet--make sure you have intalled pdo drivers
	$host='localhost'; $user='topnew'; $pass='geo'; $db='topnew';
	if ($eng=='sqlite') return new PDO($pdo="$eng:$db");
	try{
		$dbL=new PDO("$eng:host=$host;dbname=$db",$user,$pass);
		return $dbL;
	}catch (PDOException $e){}
}
?>
