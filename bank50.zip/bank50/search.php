<?php
include 'inc.page.php';
@main($pin,$len,$dlen,$cat,$fm,$to,$rem,$ccy,$avg,$pgno,$cmd);
@down();

function main($pin,$len,$dlen,$cat,$fm,$to,$rem,$ccy,$avg,$pgno,$cmd){
	if (!$len) $len=1;//1 3 5
	if (!$dlen) $dlen=19;//4 7 10 19
	$rem=trim($rem);
	$fm=main_date($fm);
	$to=main_date($to,1);
	if ($fm && $to && $fm>$to) swap($fm,$to);
	if ($cat[0]==0) unset($cat);
	else{
		if (count($cat)==1){
			if ($cat[0]>9999) $len=5;
			elseif ($cat[0]>99 && $len<3) $len=3;
		}
		foreach ($cat as $c){
			$sql_cat .=" or credit like '$c%' or debit like '$c%'";
			$sql_cat_id .=" or cat like '$c%'";
		}
		$sql_cat='and ('.substr($sql_cat,4).')';
		$sql_cat_id='and ('.substr($sql_cat_id,4).')';
	}
	if ($rem) $where=" and remark like '%$rem%'";
	if ($ccy) $where .=" and ccy='$ccy'";
	echo "<form action='search.php' method='post' name='searchform'>";
	$bsb=$pin['bsb'];
	main_form($bsb,$len,$dlen,$cat,$fm,$to,$rem,$ccy,$avg);
	$pid=$bsb['pid'];
	if ($dlen>10) return main_detail($pid,$fm,$to,$sql_cat,$where,$pgno,$cat);//stop here--bad programming style
	echo '</form>';

	if ($fm){//balance
		$rows=cms_rows("select ccy,substring(credit,1,$len),sum(amt) from bsb_book where pid=$pid and created<'$fm 00:00:00' $sql_cat $where group by 1,2");
		foreach ($rows as $row){
			$bala[$row[0]][$row[1]]=$row[2];
			$field[$row[0]][]=$row[1];
		}
		$rows=cms_rows("select ccy,substring(debit,1,$len),sum(amt) from bsb_book where pid=$pid and created<'$fm 00:00:00' $sql_cat $where group by 1,2");
		foreach ($rows as $row){
			$bala[$row[0]][$row[1]] -=$row[2];
			if (!in_array($row[1],$field[$row[0]])) $field[$row[0]][]=$row[1];
		}
	}
	if ($fm) $where .=" and created>='$fm 00:00:00'";
	if ($to) $where .=" and created<='$to 25:00:00'";
	$col2=($dlen==4 && $bsb['fin_month'] ? "year(date_add(created,interval $bsb[fin_month] month))" : "substring(created,1,$dlen)");
	$rows=cms_rows("select ccy,$col2,substring(credit,1,$len),sum(amt) from bsb_book where pid=$pid $sql_cat $where group by 1,2,3");
	foreach ($rows as $row){
		$data[$row[0]][$row[1]][$row[2]]=$row[3];
		if (!in_array($row[2],$field[$row[0]])) $field[$row[0]][]=$row[2];
	}
	$rows=cms_rows("select ccy,$col2,substring(debit,1,$len),sum(amt) from bsb_book where pid=$pid $sql_cat $where group by 1,2,3");
	foreach ($rows as $row){
		$data[$row[0]][$row[1]][$row[2]] -=$row[3];
		if (!in_array($row[2],$field[$row[0]])) $field[$row[0]][]=$row[2];
	}
	$CAT=get_CAT($pid,$len,$sql_cat_id);
	$show_avg=in_array(1,$avg);//show avg for annual|month report only
	$Inc=explode(',',$bsb['cat_income']);
	foreach ($data as $ccy=>$CCY){//cout data
		if ($cmd==lang(2704)) main_chart($ccy,$CCY,$field[$ccy]);
		else{
			unset($TTL);
			echo "<table class='grid ar pre'>";
			main_header($bsb['ccy'][$ccy],$len,$CAT,$field[$ccy]);
			if (isset($bala[$ccy])) main_data($Inc,$ccy,$len,$dlen,$CAT,$bala[$ccy],lang(2701),$field[$ccy]);
			foreach ($CCY as $date=>$Date) main_data($Inc,$ccy,$len,$dlen,$CAT,$Date,$date,$field[$ccy],$TTL,1,$show_avg);
			if (count($CCY)>1 ) main_data($Inc,$ccy,$len,$dlen,$CAT,$TTL,lang(2702),$field[$ccy]);
			if (isset($bala[$ccy])) main_data($Inc,$ccy,$len,$dlen,$CAT,$TTL,lang(2703),$field[$ccy],$dummy,0,0,$bala[$ccy]);
			echo "</table>";
		}
	}
}
function main_data($Inc,$ccy,$len,$dlen,$CAT,$data,$date,$field,&$TTL,$sumUP=0,$show_avg,$bala){
	if ($sumUP) echo "<tr><td class='bg1'><a href='search.php?fm=$date&#38;to=$date&#38;ccy=$ccy' title='",lang(603),"'>$date</a></td>";
	else echo "<tr class='bg1'><td>$date</td>";
	if ($dlen==4 && $show_avg){
		$avgTTL=12; $strAvg="<tr class='avg'><td>".lang(2705)."</td>";
	}elseif ($dlen==7 && $show_avg){
		$avgTTL=30; $strAvg="<tr class='avg'><td>".lang(2706)."</td>";
	}
	$strInc="<tr class='bg1'><td>".lang(2707)."</td>";
	$strTtl="<tr class='bg1'><td>".lang(2708)."</td>";
	foreach ($CAT as $k=>$v){
		$is_inc=in_array(substr($k,0,1),$Inc);
		if ($len==1 && in_array($k,$field)) main_data_1($is_inc,$data,$k,$TTL,$sumUP,$bala,$line,$strAvg,$avgTTL);
		else main_data_5($is_inc,$data,$k,$v,$field,$TTL,$sumUP,$bala,$line,$strAvg,$avgTTL);
	}
	if (abs($line)>=0.01) echo "<td class='red'>".number_format($line/100,2)."</td>";//funny bug?
	else echo "<td></td>";
	echo "</tr>";
	if (isset($strAvg)) echo $strAvg."<td></td></tr>";
//		echo $strInc."<td></td></tr>".$strTtl."<td></td></tr>";
}
function main_data_1($is_inc,$data,$k,&$TTL,$sumUP,$bala,&$line,&$strAvg,$avgTTL){
	if ($sumUP) $TTL[$k] +=$data[$k];
	elseif (isset($bala)) $data[$k] +=$bala[$k];
	$line +=$data[$k]; cout_num($data[$k],$is_inc);
	if (isset($strAvg)) $strAvg .=cout_pct($data[$k],$avgTTL,$is_inc);
}
function main_form($bsb,$len,$dlen,$cat,$fm,$to,$rem,$ccy,$avg){
	$arr_cat[0]=lang(2716);
	$arr_cat+=cms_row("select cat,concat(cat,' - ',category) from bsb_category where pid=$bsb[pid] order by 2",2);
	$arr=explode(',',$bsb['ccy_list']);
	$arr_ccy[]=lang(2709);
	foreach ($arr as $v) $arr_ccy[$v]=$bsb['ccy'][$v];
	echo "<table class='bg' style='border:solid 1px #cca' cellspacing='5' id='tform'>
<tr><td>",lang(2715),":</td><td title='eg: 2007-01-01'>",cms_form('text','fm',$fm,72,10),"</td>
	<td rowspan='3'>",cms_form('select','cat[]',$cat,230,$arr_cat,"style='height:145px' multiple"),"</td>
	<td>",lang(612),":</td><td>",cms_form('select','ccy',$ccy,86,$arr_ccy),"</td></tr>
<tr><td>",lang(2718),":</td><td title='eg: 2007-12-31'>",cms_form('text','to',$to,72,10),"</td>
	<td>",lang(2719),":</td><td>",cms_form('text','rem',$rem,80),"</td></tr>
<tr><td><i onclick=\"seekDate('".date('Y-01-01')."','".date('Y-12-31')."')\" class='hand'>".lang(2712)."</i>
	<br><i onclick=\"seekDate('".date('Y-m-01')."','".date('Y-m-31')."')\" class='hand'>".lang(2713)."</i>
	<br><i onclick=\"seekDate('".date('Y-m-d')."','".date('Y-m-d')."')\" class='hand'>".lang(2714)."</i>
	<br>",cms_form('button','cmd',lang(2725),50,'',"onclick=\"window.location='search.php'\""),"</td>
	<td>",cms_form('radio','dlen',$dlen,'<br>','','',array(4=>lang(2721),7=>lang(2722),10=>lang(2723),19=>lang(2724))),"</td>
	<td class='vb'>",cms_form('checkbox','avg[]',$avg,'<br>',array(1=>lang(2729),2=>"<i class='grey'>".lang(2730).'</i>',3=>"<i class='grey'>".lang(2731).'</i>')),"
	<br>",cms_form('submit','cmd',lang(2704),60),"</td>
	<td class='vb'>",cms_form('radio','len',$len,'<br>',array(1=>lang(2726),3=>lang(2727),5=>lang(2728))),"
	<br>",cms_form('submit','cmd',lang(2732),84),"</td></tr>
</table>";
}
function cout_pct($x,$ttl,$is_inc){
	if (!$is_inc) $x *=-1;
	if ($x<0) $class=" class='red'";
	return "<td$class>".number_format($x/$ttl/100,2)."</td>";
}
function main_detail($pid,$fm,$to,$sql_cat,$where,$pgno,$cat){
	$sql="from bsb_book where pid=$pid $sql_cat $where";
	if ($fm) $sql .=" and created>='$fm 00:00:00'";
	if ($to) $sql .=" and created<='$to 24:00:00'";
	$num=cms_var("select count(*) $sql");
	$pgno=ceil($pgno);
	$pagesize=20;
	$max=ceil($num/$pagesize);
	if ($pgno>$max || $pgno<1) $pgno=$max;
	echo '<p>',lang(2733,$num),': ';
	if ($num>$pagesize){
		for ($i=($pgno-4<1 ? 1 : $pgno-4);$i<$pgno+5 && $i<=$max;$i++)
			echo ($i==$pgno ? cms_form('button','pgno',$i,30,'',"class='green'") : cms_form('submit','pgno',$i,30)).' ';
	}
	echo "</p></form>";
	$sql="select * $sql order by created,his_id limit $pagesize offset ".($pgno-1)*$pagesize;
	cout_diary_list($cat,$sql);
}
function main_date($date,$max=0){
	$date=trim($date);
	$len=strlen($date);
	if ($len==10) return $date;
	if ($len<4 || $len>10) return;
	if ($len==4) return ($max ? "$date-12-31" : "$date-01-01");
	if ($len==5) return substr($date,0,4).'-'.($max ? '12-31' : '01-01');
	if ($len==6) return substr($date,0,4).'-0'.substr($date,-1).($max ? '-31' : '-01');
	if ($len==7) return ($max ? "$date-31" : "$date-01");
	if ($len==8) return substr($date,0,7).'-'.($max ? '31' : '01');
	if ($len==9) return substr($date,0,7).'-0'.substr($date,-1);
}
function main_chart($ccy,$CCY,$field){
//same color seq with chart--need to upgrade
	$color='94,48,0;51,102,153;247,143,1;90,181,110;201,34,0;238,208,181;153,102,51;153,51,51;153,153,102;102,204,204;102,102,153;51,153,153;102,204,102;153,102,102;153,153,153;51,153,51;204,102,102;51,204,153;102,153,102;153,153,255;102,153,153;204,153,102';
	$color=explode(';',$color);
	global $pin;
	$bsb=$pin['bsb'];
	$Inc=explode(',',$bsb['cat_income']);
	$CAT=cms_row("select cat,category from bsb_category where pid=$bsb[pid] and cat in (".implode(',',$field).")",2);
	sort($field,SORT_STRING);
	echo "<span class='chartcolor bg' style='color:#000'>&nbsp; {$bsb[ccy][$ccy]} &nbsp;</span>";
	foreach ($field as $k=>$v) echo "<span class='chartcolor' style='background:rgb(".$color[$k].")'>".$CAT[$v]."</span>";
	$str='acc,date,amt';
	foreach ($field as $v){
		$is_inc=in_array(substr($v,0,1),$Inc);
		foreach ($CCY as $date=>$data){
			$amt=$data[$v]*($is_inc ? 1 : -1);
			$v=round($v,$bsb['rep_round']);
			$str .=";$v,$date,".($amt/100);
		}
	}
	echo "<p class='clear'><img src='bChart.php?w=fix&#38;legend=0&#38;yFormat=format|0|.|,&#38;gapL=20&#38;valShow=1&#38;valAngle=90&#38;gapT=20&#38;fmt=strV2&#38;data=$str'></p>";
}
?>
